const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs').promises;
const path = require('path');
const { Telegraf, Markup } = require('telegraf');

const YOUR_BOT_TOKEN = "YOUR_TOKEN_HERE";
const ADMIN_CHAT_IDS = ["123456"];
const INITIAL_CHAT_IDS = ["-100123456"];

const LOGIN_URL = "https://www.ivasms.com/login";
const BASE_URL = "https://www.ivasms.com/";
const SMS_API_ENDPOINT = "https://www.ivasms.com/portal/sms/received/getsms";
const NUMBER_ENDPOINT = "https://www.ivasms.com/portal/sms/received/getsms/number";
const SMS_NUMBER_ENDPOINT = "https://www.ivasms.com/portal/sms/received/getsms/number/sms";
const USERNAME = "akunmabar1@whoiszamsxit.web.id";
const PASSWORD = "PASSWORD_ANDA";

let POLLING_INTERVAL_SECONDS = 60;
const STATE_FILE = "processed_sms_ids.json";
const CHAT_IDS_FILE = "chat_ids.json";
const SETTINGS_FILE = "settings.json";
const TEMP_STATE_FILE = "temp_state.json";
const COOKIE_FILE = "ivasms_cookie.json";
const COUNTRY_CACHE_FILE = "country_cache.json";

const COUNTRY_FLAGS = {
    "Unknown Country": "🏴‍☠️",
    "Indonesia": "🇮🇩",
    "Malaysia": "🇲🇾",
    "Singapore": "🇸🇬",
    "Thailand": "🇹🇭",
    "Vietnam": "🇻🇳",
    "Philippines": "🇵🇭",
    "India": "🇮🇳",
    "USA": "🇺🇸",
    "UK": "🇬🇧",
    "Australia": "🇦🇺",
    "Japan": "🇯🇵",
    "Korea": "🇰🇷",
    "China": "🇨🇳",
    "Gambia": "🇬🇲"
};

const SERVICE_EMOJIS = {
    "Unknown": "❓",
    "WhatsApp": "💚",
    "Telegram": "✈️",
    "Google": "🔴",
    "Facebook": "🔵",
    "Instagram": "📸",
    "Twitter": "🐦",
    "TikTok": "🎵",
    "Shopee": "🛍️",
    "Tokopedia": "🛒",
    "Lazada": "📦",
    "Gojek": "🟢",
    "Grab": "🟩",
    "OVO": "💜",
    "Dana": "💙",
    "LinkAja": "❤️"
};

let axiosClient = null;
let currentCookies = null;
let countryCache = null;
let useManualCookie = false;

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function loadChatIds() {
    try {
        await fs.access(CHAT_IDS_FILE);
        const data = await fs.readFile(CHAT_IDS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        await fs.writeFile(CHAT_IDS_FILE, JSON.stringify(INITIAL_CHAT_IDS, null, 4));
        return INITIAL_CHAT_IDS;
    }
}

async function saveChatIds(chatIds) {
    await fs.writeFile(CHAT_IDS_FILE, JSON.stringify(chatIds, null, 4));
}

async function loadProcessedIds() {
    try {
        await fs.access(STATE_FILE);
        const data = await fs.readFile(STATE_FILE, 'utf8');
        return new Set(JSON.parse(data));
    } catch (error) {
        return new Set();
    }
}

async function saveProcessedId(sid) {
    const ids = await loadProcessedIds();
    ids.add(sid);
    await fs.writeFile(STATE_FILE, JSON.stringify([...ids], null, 4));
}

async function loadSettings() {
    try {
        await fs.access(SETTINGS_FILE);
        const data = await fs.readFile(SETTINGS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        const defaultSettings = {
            interval: POLLING_INTERVAL_SECONDS,
            notifications: true,
            messageFormat: "detailed"
        };
        await fs.writeFile(SETTINGS_FILE, JSON.stringify(defaultSettings, null, 4));
        return defaultSettings;
    }
}

async function saveSettings(settings) {
    await fs.writeFile(SETTINGS_FILE, JSON.stringify(settings, null, 4));
}

async function loadTempState() {
    try {
        await fs.access(TEMP_STATE_FILE);
        const data = await fs.readFile(TEMP_STATE_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return { waitingFor: null, tempData: {} };
    }
}

async function saveTempState(state) {
    await fs.writeFile(TEMP_STATE_FILE, JSON.stringify(state, null, 4));
}

async function saveCookies(cookieString) {
    await fs.writeFile(COOKIE_FILE, JSON.stringify({ cookie: cookieString, timestamp: Date.now() }, null, 4));
    currentCookies = cookieString;
}

async function loadCookies() {
    try {
        await fs.access(COOKIE_FILE);
        const data = await fs.readFile(COOKIE_FILE, 'utf8');
        const parsed = JSON.parse(data);
        currentCookies = parsed.cookie;
        return parsed;
    } catch (error) {
        return null;
    }
}

async function saveCountryCache(countryData) {
    await fs.writeFile(COUNTRY_CACHE_FILE, JSON.stringify({ data: countryData, timestamp: Date.now() }, null, 4));
    countryCache = countryData;
}

async function loadCountryCache() {
    try {
        await fs.access(COUNTRY_CACHE_FILE);
        const data = await fs.readFile(COUNTRY_CACHE_FILE, 'utf8');
        const parsed = JSON.parse(data);
        if (Date.now() - parsed.timestamp < 3600000) {
            countryCache = parsed.data;
            return parsed.data;
        }
        return null;
    } catch (error) {
        return null;
    }
}

function escapeHtml(text) {
    if (!text) return '';
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function detectService(text) {
    text = text.toLowerCase();
    if (text.includes('whatsapp')) return 'WhatsApp';
    if (text.includes('telegram')) return 'Telegram';
    if (text.includes('google')) return 'Google';
    if (text.includes('facebook') || text.includes('fb')) return 'Facebook';
    if (text.includes('instagram') || text.includes('ig')) return 'Instagram';
    if (text.includes('twitter') || text.includes('x')) return 'Twitter';
    if (text.includes('tiktok')) return 'TikTok';
    if (text.includes('shopee')) return 'Shopee';
    if (text.includes('tokopedia')) return 'Tokopedia';
    if (text.includes('lazada')) return 'Lazada';
    if (text.includes('gojek')) return 'Gojek';
    if (text.includes('grab')) return 'Grab';
    if (text.includes('ovo')) return 'OVO';
    if (text.includes('dana')) return 'Dana';
    if (text.includes('linkaja')) return 'LinkAja';
    return 'Unknown';
}

function getCountryFlag(countryName) {
    if (COUNTRY_FLAGS[countryName]) {
        return COUNTRY_FLAGS[countryName];
    }
    for (const [key, flag] of Object.entries(COUNTRY_FLAGS)) {
        if (countryName.toLowerCase().includes(key.toLowerCase())) {
            return flag;
        }
    }
    return "🏴‍☠️";
}

function createMainMenu() {
    return Markup.inlineKeyboard([
        [Markup.button.callback("📊 STATUS", "status_bot")],
        [Markup.button.callback("🌍 LIVE COUNTRIES", "live_countries")],
        [Markup.button.callback("👥 CHATS", "manage_chats")],
        [Markup.button.callback("⚙️ SETTINGS", "settings_menu")],
        [Markup.button.callback("📨 SMS LOG", "list_sms")],
        [Markup.button.callback("🍪 GET COOKIE", "get_cookie")],
        [Markup.button.callback("🔄 RESTART", "restart_bot"), Markup.button.callback("🗑️ RESET", "delete_all_data")]
    ]);
}

function createBackButton() {
    return Markup.inlineKeyboard([
        [Markup.button.callback("🔙 BACK TO MAIN", "back_to_main")]
    ]);
}

async function initAxiosWithCookie() {
    const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
    };
    
    const savedCookie = await loadCookies();
    if (savedCookie && savedCookie.cookie) {
        headers['Cookie'] = savedCookie.cookie;
        useManualCookie = true;
        console.log('✅ Using manual cookie from browser');
    } else {
        console.log('⚠️ No cookie found, will try login');
        useManualCookie = false;
    }
    
    axiosClient = axios.create({
        timeout: 45000,
        maxRedirects: 5,
        headers: headers
    });
    
    return axiosClient;
}

async function refreshCookie() {
    if (useManualCookie) {
        console.log('📌 Using manual cookie, skip auto login');
        return true;
    }
    
    try {
        console.log('Attempting to login to IVASMS...');
        await delay(3000);
        
        const client = axios.create({
            timeout: 45000,
            maxRedirects: 5,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'
            }
        });
        
        const lp = await client.get(LOGIN_URL);
        const $ = cheerio.load(lp.data);
        const token = $('input[name="_token"]').val();
        
        if (!token) {
            console.error('CSRF token not found');
            return false;
        }
        
        const loginData = new URLSearchParams();
        loginData.append('email', USERNAME);
        loginData.append('password', PASSWORD);
        loginData.append('_token', token);
        
        const lr = await client.post(LOGIN_URL, loginData, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            maxRedirects: 5
        });
        
        const setCookie = lr.headers['set-cookie'];
        if (setCookie && setCookie.length > 0) {
            const cookieString = setCookie.map(c => c.split(';')[0]).join('; ');
            await saveCookies(cookieString);
            if (axiosClient) {
                axiosClient.defaults.headers['Cookie'] = cookieString;
            }
            console.log('✅ Cookie saved successfully');
            return true;
        }
        
        console.error('Login failed');
        return false;
    } catch (error) {
        console.error('Failed to refresh cookie:', error.response?.status || error.message);
        if (error.response?.status === 403) {
            console.error('❌ IP BLOCKED - Please use manual cookie method');
        }
        return false;
    }
}

async function ensureValidSession() {
    if (!axiosClient) {
        await initAxiosWithCookie();
    }
    
    if (!currentCookies && !useManualCookie) {
        await refreshCookie();
    }
    
    if (useManualCookie && currentCookies) {
        try {
            const testRes = await axiosClient.get(BASE_URL, { timeout: 15000 });
            if (testRes.request.res.responseUrl && testRes.request.res.responseUrl.includes('login')) {
                console.log('Manual cookie expired, need new cookie');
                useManualCookie = false;
                await refreshCookie();
            } else {
                console.log('✅ Manual cookie valid');
            }
        } catch (error) {
            console.log('Cookie check failed:', error.message);
        }
    }
    
    return axiosClient;
}

async function fetchLiveCountries() {
    try {
        await ensureValidSession();
        
        const today = new Date();
        const start = new Date(today);
        start.setDate(start.getDate() - 7);
        const fd = start.toLocaleDateString('en-US');
        const td = today.toLocaleDateString('en-US');
        
        const profileRes = await axiosClient.get(BASE_URL);
        const p$ = cheerio.load(profileRes.data);
        const csrf = p$('meta[name="csrf-token"]').attr('content');
        
        if (!csrf) return null;
        
        const payload = new URLSearchParams({
            'from': fd,
            'to': td,
            '_token': csrf
        });
        
        const res = await axiosClient.post(SMS_API_ENDPOINT, payload, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        
        const $ = cheerio.load(res.data);
        const groups = $('div.pointer');
        
        const countriesMap = new Map();
        const numbersMap = new Map();
        
        for (let i = 0; i < groups.length; i++) {
            const element = groups[i];
            const onclick = $(element).attr('onclick') || '';
            const match = onclick.match(/getDetials\('(.+?)'\)/);
            if (match) {
                const gid = match[1];
                const countryName = $(element).text().trim().replace(/[0-9]/g, '').trim();
                
                if (countryName && countryName.length > 0 && countryName.length < 50) {
                    const count = countriesMap.get(countryName) || 0;
                    countriesMap.set(countryName, count + 1);
                    
                    const numPayload = new URLSearchParams({
                        'start': fd,
                        'end': td,
                        'range': gid,
                        '_token': csrf
                    });
                    
                    try {
                        const numRes = await axiosClient.post(NUMBER_ENDPOINT, numPayload, {
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                        });
                        
                        const n$ = cheerio.load(numRes.data);
                        const numbers = n$("div[onclick*='getDetialsNumber']").map((_, d) => n$(d).text().trim()).get();
                        
                        if (numbers.length > 0) {
                            numbersMap.set(countryName, numbers);
                        }
                    } catch (err) {
                        console.error(`Error fetching numbers for ${countryName}:`, err.message);
                    }
                    
                    await delay(500);
                }
            }
        }
        
        const sortedCountries = Array.from(countriesMap.entries())
            .sort((a, b) => b[1] - a[1])
            .map(entry => ({ name: entry[0], traffic: entry[1], numbers: numbersMap.get(entry[0]) || [] }));
        
        const highTraffic = sortedCountries.slice(0, 8);
        const active = sortedCountries.slice(0, 15);
        const popular = sortedCountries.slice(0, 20);
        
        const result = {
            allCountries: sortedCountries,
            highTraffic: highTraffic,
            active: active,
            popular: popular,
            numbersMap: Object.fromEntries(numbersMap),
            lastUpdate: Date.now()
        };
        
        await saveCountryCache(result);
        return result;
    } catch (error) {
        console.error('Error fetching live countries:', error.message);
        return null;
    }
}

async function getNumbersByCountry(countryName) {
    try {
        await ensureValidSession();
        
        const today = new Date();
        const start = new Date(today);
        start.setDate(start.getDate() - 7);
        const fd = start.toLocaleDateString('en-US');
        const td = today.toLocaleDateString('en-US');
        
        const profileRes = await axiosClient.get(BASE_URL);
        const p$ = cheerio.load(profileRes.data);
        const csrf = p$('meta[name="csrf-token"]').attr('content');
        
        if (!csrf) return [];
        
        const payload = new URLSearchParams({
            'from': fd,
            'to': td,
            '_token': csrf
        });
        
        const res = await axiosClient.post(SMS_API_ENDPOINT, payload, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        
        const $ = cheerio.load(res.data);
        const groups = $('div.pointer');
        let targetGid = null;
        
        for (let i = 0; i < groups.length; i++) {
            const element = groups[i];
            const text = $(element).text().trim();
            if (text.includes(countryName) || text.toLowerCase() === countryName.toLowerCase()) {
                const onclick = $(element).attr('onclick') || '';
                const match = onclick.match(/getDetials\('(.+?)'\)/);
                if (match) {
                    targetGid = match[1];
                    break;
                }
            }
        }
        
        if (!targetGid) return [];
        
        const numPayload = new URLSearchParams({
            'start': fd,
            'end': td,
            'range': targetGid,
            '_token': csrf
        });
        
        const numRes = await axiosClient.post(NUMBER_ENDPOINT, numPayload, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        
        const n$ = cheerio.load(numRes.data);
        const numbers = n$("div[onclick*='getDetialsNumber']").map((_, d) => n$(d).text().trim()).get();
        
        return numbers;
    } catch (error) {
        console.error(`Error fetching numbers for ${countryName}:`, error.message);
        return [];
    }
}

async function fetchSms() {
    try {
        await ensureValidSession();
        
        const today = new Date();
        const start = new Date(today);
        start.setDate(start.getDate() - 1);
        const fd = start.toLocaleDateString('en-US');
        const td = today.toLocaleDateString('en-US');
        
        const profileRes = await axiosClient.get(BASE_URL);
        const p$ = cheerio.load(profileRes.data);
        const csrf = p$('meta[name="csrf-token"]').attr('content');
        
        if (!csrf) return [];
        
        const payload = new URLSearchParams({
            'from': fd,
            'to': td,
            '_token': csrf
        });
        
        const res = await axiosClient.post(SMS_API_ENDPOINT, payload, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        
        const $ = cheerio.load(res.data);
        const groups = $('div.pointer');
        
        if (groups.length === 0) return [];
        
        const ids = [];
        groups.each((_, element) => {
            const onclick = $(element).attr('onclick') || '';
            const match = onclick.match(/getDetials\('(.+?)'\)/);
            if (match) ids.push(match[1]);
        });
        
        const allMsgs = [];
        
        for (const gid of ids) {
            const nPayload = new URLSearchParams({
                'start': fd,
                'end': td,
                'range': gid,
                '_token': csrf
            });
            
            const nr = await axiosClient.post(NUMBER_ENDPOINT, nPayload, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            });
            
            const n$ = cheerio.load(nr.data);
            const divs = n$("div[onclick*='getDetialsNumber']");
            const nums = divs.map((_, d) => n$(d).text().trim()).get();
            
            for (const num of nums) {
                const sPayload = new URLSearchParams({
                    'start': fd,
                    'end': td,
                    'Number': num,
                    'Range': gid,
                    '_token': csrf
                });
                
                const sr = await axiosClient.post(SMS_NUMBER_ENDPOINT, sPayload, {
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                });
                
                const s$ = cheerio.load(sr.data);
                const cards = s$('div.card-body');
                
                cards.each((_, card) => {
                    const p = s$(card).find('p.mb-0');
                    if (p.length === 0) return;
                    
                    const text = p.text().trim();
                    const sid = `${num}-${text.substring(0, 50)}`;
                    
                    let code = "N/A";
                    const mcode = text.match(/(\d{4,8})/);
                    if (mcode) code = mcode[1];
                    
                    const service = detectService(text);
                    const countryName = gid;
                    const flag = getCountryFlag(countryName);
                    const serviceEmoji = SERVICE_EMOJIS[service] || "❓";
                    
                    allMsgs.push({
                        "id": sid,
                        "time": today.toISOString().replace('T', ' ').substring(0, 19),
                        "number": num,
                        "country": countryName,
                        "flag": flag,
                        "service": service,
                        "serviceEmoji": serviceEmoji,
                        "code": code,
                        "full_sms": text
                    });
                });
            }
        }
        return allMsgs;
    } catch (error) {
        console.error('Error fetching SMS:', error.message);
        if (error.response && error.response.status === 401) {
            useManualCookie = false;
            await refreshCookie();
        }
        return [];
    }
}

async function sendMsg(bot, chatId, data, settings) {
    let msg;
    if (settings.messageFormat === 'simple') {
        msg = `<blockquote>
<b>🔔 NEW OTP</b>

${data.serviceEmoji} <b>${escapeHtml(data.service)}</b>

📞 <code>${escapeHtml(data.number)}</code>
🔑 <b><code>${escapeHtml(data.code)}</code></b>
🌍 ${data.flag} ${escapeHtml(data.country)}
⏱️ ${escapeHtml(data.time)}

IVASMS BOT
</blockquote>`;
    } else {
        msg = `<blockquote>
<b>🔔 NEW OTP DETECTED</b>

${data.serviceEmoji} <b>${escapeHtml(data.service)}</b>

<b>📞 Number:</b> <code>${escapeHtml(data.number)}</code>
<b>🔑 OTP Code:</b> <b><code>${escapeHtml(data.code)}</code></b>
<b>🌍 Country:</b> ${data.flag} <b>${escapeHtml(data.country)}</b>
<b>⏱️ Timestamp:</b> <code>${escapeHtml(data.time)}</code>

<b>💬 Message:</b>
${escapeHtml(data.full_sms.substring(0, 400))}

IVASMS BOT PREMIUM
</blockquote>`;
    }
    
    try {
        await bot.telegram.sendMessage(chatId, msg, { parse_mode: 'HTML' });
    } catch (error) {
        console.error(`Failed to send to ${chatId}:`, error.message);
    }
}

let isChecking = false;
let retryCount = 0;

async function checkSms(bot) {
    if (isChecking) return;
    isChecking = true;
    
    try {
        const msgs = await fetchSms();
        if (msgs.length === 0) {
            isChecking = false;
            return;
        }
        
        const processed = await loadProcessedIds();
        const chats = await loadChatIds();
        const settings = await loadSettings();
        
        for (const m of msgs) {
            if (!processed.has(m.id)) {
                if (settings.notifications) {
                    for (const cid of chats) {
                        await sendMsg(bot, cid, m, settings);
                    }
                }
                await saveProcessedId(m.id);
                console.log(`New SMS: ${m.id.substring(0, 30)}`);
                retryCount = 0;
            }
        }
    } catch (error) {
        console.error('Error in checkSms:', error.message);
        retryCount++;
        if (retryCount > 3) {
            console.log('Multiple failures, refreshing session...');
            useManualCookie = false;
            await refreshCookie();
            retryCount = 0;
        }
    } finally {
        isChecking = false;
    }
}

async function testIvasmsConnection() {
    const startTime = Date.now();
    try {
        await ensureValidSession();
        const testRes = await axiosClient.get(BASE_URL, { timeout: 15000 });
        const isLoggedIn = !testRes.request.res.responseUrl.includes('login');
        const responseTime = Date.now() - startTime;
        return { success: true, responseTime, loginSuccess: isLoggedIn };
    } catch (error) {
        return { success: false, error: error.message, responseTime: Date.now() - startTime };
    }
}

function setupCommands(bot) {
    bot.command('start', async (ctx) => {
        try {
            const uid = String(ctx.from.id);
            const isAdmin = ADMIN_CHAT_IDS.includes(uid);
            
            const welcomeMsg = `<blockquote>
<b>🤖 IVASMS BOT</b>

<b>👋 Welcome</b> ${isAdmin ? '👑 Admin' : '👤 User'}

<b>✨ Features:</b>
📨 Auto fetch SMS from IVASMS
🔔 Real-time OTP notifications
🌍 Live country detection
🍪 Manual cookie support

<b>📌 Select option below:</b>
</blockquote>`;

            await ctx.reply(welcomeMsg, { parse_mode: 'HTML', ...createMainMenu() });
        } catch (error) {
            console.error('Start error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b>\nFailed to load menu.</blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('get_cookie', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.deleteMessage();
            await ctx.reply('<blockquote><b>🍪 MENGAMBIL COOKIE...</b>\n\nMohon tunggu sebentar...</blockquote>', { parse_mode: 'HTML' });
            
            const client = axios.create({
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36'
                }
            });
            
            const lp = await client.get(LOGIN_URL);
            const $ = cheerio.load(lp.data);
            const token = $('input[name="_token"]').val();
            
            if (!token) {
                return await ctx.reply('<blockquote><b>❌ GAGAL</b>\n\nTidak dapat mengambil token CSRF.</blockquote>', { parse_mode: 'HTML' });
            }
            
            const loginData = new URLSearchParams();
            loginData.append('email', USERNAME);
            loginData.append('password', PASSWORD);
            loginData.append('_token', token);
            
            const lr = await client.post(LOGIN_URL, loginData, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                maxRedirects: 5
            });
            
            const setCookie = lr.headers['set-cookie'];
            if (setCookie && setCookie.length > 0) {
                const cookieString = setCookie.map(c => c.split(';')[0]).join('; ');
                await saveCookies(cookieString);
                
                if (axiosClient) {
                    axiosClient.defaults.headers['Cookie'] = cookieString;
                }
                useManualCookie = true;
                
                await ctx.reply(`<blockquote>
<b>✅ COOKIE BERHASIL DISIMPAN!</b>

<b>🔐 Status:</b> Manual Cookie Active
<b>📌 Panjang Cookie:</b> ${cookieString.length} characters

Bot sekarang akan menggunakan cookie ini untuk semua request ke IVASMS.

💡 Cookie ini akan otomatis digunakan hingga expired.
</blockquote>`, { parse_mode: 'HTML', ...createBackButton() });
            } else {
                await ctx.reply(`<blockquote>
<b>❌ GAGAL LOGIN</b>

Server tidak mengirimkan cookie.

<b>Cek:</b>
• Username: ${USERNAME}
• Password: [tersembunyi]

Pastikan username dan password benar.
</blockquote>`, { parse_mode: 'HTML' });
            }
        } catch (error) {
            console.error('Get cookie action error:', error);
            await ctx.reply(`<blockquote><b>❌ ERROR</b>\n\n${error.response?.status || error.message}\n\nIP server mungkin diblokir oleh IVASMS.</blockquote>`, { parse_mode: 'HTML' });
        }
    });

    bot.action('live_countries', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.deleteMessage();
            await ctx.reply('<blockquote><b>🌍 FETCHING LIVE COUNTRIES...</b></blockquote>', { parse_mode: 'HTML' });
            
            const countryData = await fetchLiveCountries();
            
            if (!countryData || !countryData.highTraffic || countryData.highTraffic.length === 0) {
                return await ctx.reply('<blockquote><b>❌ NO DATA</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            const buttons = [];
            for (const country of countryData.highTraffic) {
                const flag = getCountryFlag(country.name);
                buttons.push([Markup.button.callback(`${flag} ${country.name} (${country.traffic} SMS)`, `view_numbers_${country.name}`)]);
            }
            buttons.push([Markup.button.callback("🔙 BACK", "back_to_main")]);
            
            const msg = `<blockquote>
<b>🌍 LIVE COUNTRIES - HIGH TRAFFIC</b>

Bot otomatis mendeteksi negara dengan traffic SMS tertinggi.

<b>🔥 Top ${countryData.highTraffic.length} Countries:</b>
${countryData.highTraffic.map((c, i) => `${i+1}. ${getCountryFlag(c.name)} <b>${c.name}</b> - <code>${c.traffic} SMS</code>`).join('\n')}

<b>📌 Klik negara untuk lihat nomor:</b>
</blockquote>`;
            
            await ctx.reply(msg, { parse_mode: 'HTML', ...Markup.inlineKeyboard(buttons) });
        } catch (error) {
            console.error('Live countries error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action(/view_numbers_(.+)/, async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            const countryName = ctx.match[1];
            const flag = getCountryFlag(countryName);
            
            await ctx.deleteMessage();
            await ctx.reply(`<blockquote><b>📞 FETCHING NUMBERS FOR ${flag} ${countryName}...</b></blockquote>`, { parse_mode: 'HTML' });
            
            const numbers = await getNumbersByCountry(countryName);
            
            if (!numbers || numbers.length === 0) {
                return await ctx.reply(`<blockquote><b>❌ NO NUMBERS FOUND</b></blockquote>`, { parse_mode: 'HTML', ...createBackButton() });
            }
            
            const numbersList = numbers.map((num, i) => `${i+1}. <code>${escapeHtml(num)}</code>`).join('\n');
            
            const msg = `<blockquote>
<b>📞 AVAILABLE NUMBERS</b>
<b>${flag} ${countryName}</b>

<b>Total:</b> <code>${numbers.length} numbers</code>

${numbersList}
</blockquote>`;
            
            const numberButtons = [];
            for (let i = 0; i < Math.min(numbers.length, 10); i++) {
                numberButtons.push([Markup.button.callback(`📱 ${numbers[i]}`, `view_sms_${countryName}_${numbers[i]}`)]);
            }
            numberButtons.push([Markup.button.callback("🔙 BACK TO COUNTRIES", "live_countries")]);
            numberButtons.push([Markup.button.callback("🏠 MAIN MENU", "back_to_main")]);
            
            await ctx.reply(msg, { parse_mode: 'HTML', ...Markup.inlineKeyboard(numberButtons) });
        } catch (error) {
            console.error('View numbers error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action(/view_sms_(.+)_(.+)/, async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            const countryName = ctx.match[1];
            const number = ctx.match[2];
            const flag = getCountryFlag(countryName);
            
            const processedIds = await loadProcessedIds();
            const relatedSms = Array.from(processedIds).filter(id => id.includes(number)).slice(-10);
            
            if (relatedSms.length === 0) {
                return await ctx.reply(`<blockquote><b>📭 NO SMS HISTORY</b></blockquote>`, { parse_mode: 'HTML', ...createBackButton() });
            }
            
            const smsList = relatedSms.map((sms, i) => `${i+1}. <code>${sms.substring(0, 60)}...</code>`).join('\n');
            
            const msg = `<blockquote>
<b>📨 OTP HISTORY</b>
<b>${flag} ${countryName}</b>
<b>📞 Number:</b> <code>${number}</code>

<b>Total SMS:</b> <code>${relatedSms.length}</code>

${smsList}
</blockquote>`;
            
            await ctx.reply(msg, { parse_mode: 'HTML', ...createBackButton() });
        } catch (error) {
            console.error('View SMS error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('status_bot', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.deleteMessage();
            
            const chatIds = await loadChatIds();
            const processedIds = await loadProcessedIds();
            const settings = await loadSettings();
            const uptime = Math.floor(process.uptime() / 60);
            const memory = Math.round(process.memoryUsage().rss / 1024 / 1024);
            const sessionStatus = useManualCookie ? '🟢 MANUAL COOKIE' : (currentCookies ? '🟢 ACTIVE' : '🟡 PENDING');
            
            const statusMsg = `<blockquote>
<b>📊 SYSTEM STATUS</b>

<b>🟢 Bot Status:</b> <code>Running</code>
<b>👥 Active Chats:</b> <code>${chatIds.length}</code>
<b>📨 Total SMS:</b> <code>${processedIds.size}</code>
<b>⏰ Interval:</b> <code>${settings.interval}s</code>
<b>🔔 Notification:</b> <code>${settings.notifications ? 'ON' : 'OFF'}</code>
<b>🔐 Session:</b> <code>${sessionStatus}</code>

<b>🖥️ Server Info:</b>
<b>Platform:</b> <code>${process.platform}</code>
<b>Uptime:</b> <code>${uptime} minutes</code>
<b>Memory:</b> <code>${memory} MB</code>

✅ All systems operational
</blockquote>`;
            
            await ctx.reply(statusMsg, { parse_mode: 'HTML', ...createBackButton() });
        } catch (error) {
            console.error('Status error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('manage_chats', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.deleteMessage();
            
            await ctx.reply('<blockquote><b>👥 CHAT MANAGER</b></blockquote>', { 
                parse_mode: 'HTML', 
                ...Markup.inlineKeyboard([
                    [Markup.button.callback("➕ ADD CHAT", "add_chat_menu")],
                    [Markup.button.callback("➖ REMOVE CHAT", "remove_chat_menu")],
                    [Markup.button.callback("📋 LIST CHATS", "list_chats_menu")],
                    [Markup.button.callback("🧹 CLEAR ALL", "clear_chats_menu")],
                    [Markup.button.callback("🔙 BACK", "back_to_main")]
                ])
            });
        } catch (error) {
            console.error('Manage chats error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('settings_menu', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.deleteMessage();
            
            const settings = await loadSettings();
            const notifStatus = settings.notifications ? '🟢 ACTIVE' : '🔴 INACTIVE';
            const formatStatus = settings.messageFormat === 'detailed' ? '📝 DETAILED' : '📄 SIMPLE';
            
            const msg = `<blockquote>
<b>⚙️ SETTINGS PANEL</b>

<b>⏰ Interval:</b> <code>${settings.interval} seconds</code>
<b>🔔 Notifications:</b> <code>${notifStatus}</code>
<b>📱 Message Format:</b> <code>${formatStatus}</code>
<b>🌍 Country System:</b> <code>LIVE DYNAMIC</code>
<b>🔐 Auth Method:</b> <code>${useManualCookie ? 'MANUAL COOKIE' : 'AUTO LOGIN'}</code>
</blockquote>`;
            
            await ctx.reply(msg, { 
                parse_mode: 'HTML', 
                ...Markup.inlineKeyboard([
                    [Markup.button.callback("⏰ CHANGE INTERVAL", "change_interval")],
                    [Markup.button.callback("🔔 TOGGLE NOTIF", "toggle_notifications")],
                    [Markup.button.callback("📱 CHANGE FORMAT", "change_message_format")],
                    [Markup.button.callback("🔧 TEST CONNECTION", "test_connection")],
                    [Markup.button.callback("🔙 BACK", "back_to_main")]
                ])
            });
        } catch (error) {
            console.error('Settings error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('list_sms', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.deleteMessage();
            
            const processedIds = await loadProcessedIds();
            const recentSms = Array.from(processedIds).slice(-10);
            
            if (recentSms.length === 0) {
                return await ctx.reply('<blockquote><b>📭 SMS HISTORY</b>\n\nNo SMS processed yet.</blockquote>', { parse_mode: 'HTML', ...createBackButton() });
            }
            
            const smsList = recentSms.map((sms, i) => `${i+1}. <code>${sms.substring(0, 60)}...</code>`).join('\n');
            
            const msg = `<blockquote>
<b>📨 SMS HISTORY</b>

<b>Last 10 SMS:</b>

${smsList}

<b>Total:</b> <code>${processedIds.size} SMS</code>
</blockquote>`;
            
            await ctx.reply(msg, { parse_mode: 'HTML', ...createBackButton() });
        } catch (error) {
            console.error('List SMS error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('restart_bot', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.reply('<blockquote><b>🔄 RESTARTING</b>\n\nBot will restart in 3 seconds...</blockquote>', { parse_mode: 'HTML' });
            
            setTimeout(() => {
                process.exit(0);
            }, 3000);
        } catch (error) {
            console.error('Restart error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('delete_all_data', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.reply(`<blockquote>
<b>🗑️ RESET DATA</b>

⚠️ DESTRUCTIVE ACTION

<b>This will permanently delete:</b>
• All chat IDs
• SMS history

<b>CANNOT BE UNDONE</b>

Are you absolutely sure?
</blockquote>`, {
                parse_mode: 'HTML',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback("✅ YES, DELETE ALL", "confirm_delete_all")],
                    [Markup.button.callback("❌ NO, CANCEL", "cancel_delete")]
                ])
            });
        } catch (error) {
            console.error('Delete data error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('add_chat_menu', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.reply(`<blockquote>
<b>➕ ADD CHAT ID</b>

Send the chat ID you want to add.

<b>Examples:</b>
📁 Group: <code>-100123456789</code>
👤 Private: <code>123456789</code>

Type <code>/batal</code> to cancel.
</blockquote>`, { parse_mode: 'HTML' });
            
            await saveTempState({ waitingFor: 'add_chat', tempData: {} });
        } catch (error) {
            console.error('Add chat error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('remove_chat_menu', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            const chatIds = await loadChatIds();
            
            if (chatIds.length === 0) {
                return await ctx.reply('<blockquote><b>📭 REMOVE CHAT</b>\n\nNo chats registered.</blockquote>', { parse_mode: 'HTML' });
            }
            
            const buttons = [];
            for (const id of chatIds) {
                buttons.push([Markup.button.callback(`❌ ${id}`, `remove_chat_${id}`)]);
            }
            buttons.push([Markup.button.callback("🔙 BACK", "back_to_main")]);
            
            await ctx.reply(`<blockquote>
<b>➖ REMOVE CHAT</b>

Select chat to remove:

<b>📌 Registered Chats:</b> ${chatIds.length} total
</blockquote>`, { parse_mode: 'HTML', ...Markup.inlineKeyboard(buttons) });
        } catch (error) {
            console.error('Remove chat error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action(/remove_chat_(.+)/, async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            const targetId = ctx.match[1];
            const chatIds = await loadChatIds();
            const index = chatIds.indexOf(targetId);
            
            if (index > -1) {
                chatIds.splice(index, 1);
                await saveChatIds(chatIds);
                await ctx.reply(`<blockquote><b>✅ SUCCESS</b>\n\nChat ID <code>${targetId}</code> has been removed.</blockquote>`, { parse_mode: 'HTML' });
            } else {
                await ctx.reply(`<blockquote><b>❌ FAILED</b>\n\nChat ID <code>${targetId}</code> not found.</blockquote>`, { parse_mode: 'HTML' });
            }
        } catch (error) {
            console.error('Remove chat action error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('list_chats_menu', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            const chatIds = await loadChatIds();
            
            if (chatIds.length === 0) {
                return await ctx.reply('<blockquote><b>📭 CHAT LIST</b>\n\nNo chats registered.</blockquote>', { parse_mode: 'HTML' });
            }
            
            const chatList = chatIds.map((id, i) => `${i+1}. <code>${id}</code>`).join('\n');
            
            const msg = `<blockquote>
<b>👥 CHAT LIST</b>

${chatList}

<b>Total:</b> <code>${chatIds.length} chats</code>
</blockquote>`;
            
            await ctx.reply(msg, { parse_mode: 'HTML', ...createBackButton() });
        } catch (error) {
            console.error('List chats error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('clear_chats_menu', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.reply(`<blockquote>
<b>🧹 CLEAR ALL CHATS</b>

⚠️ This will remove ALL registered chats.

<b>CANNOT BE UNDONE</b>

Confirm action:
</blockquote>`, {
                parse_mode: 'HTML',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback("✅ YES, CLEAR ALL", "confirm_clear_chats")],
                    [Markup.button.callback("❌ NO, CANCEL", "back_to_main")]
                ])
            });
        } catch (error) {
            console.error('Clear chats error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('confirm_clear_chats', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await saveChatIds([]);
            await ctx.reply('<blockquote><b>✅ SUCCESS</b>\n\nAll chats have been cleared.</blockquote>', { parse_mode: 'HTML' });
        } catch (error) {
            console.error('Confirm clear error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('change_interval', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.reply(`<blockquote>
<b>⏰ CHANGE INTERVAL</b>

Send polling interval in seconds.

<b>Range:</b> <code>5 - 300 seconds</code>

<b>Examples:</b>
• <code>5</code> (5 seconds)
• <code>30</code> (30 seconds)

Type <code>/batal</code> to cancel.
</blockquote>`, { parse_mode: 'HTML' });
            
            await saveTempState({ waitingFor: 'change_interval', tempData: {} });
        } catch (error) {
            console.error('Change interval error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('toggle_notifications', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            const settings = await loadSettings();
            settings.notifications = !settings.notifications;
            await saveSettings(settings);
            const status = settings.notifications ? 'ENABLED' : 'DISABLED';
            
            await ctx.reply(`<blockquote><b>🔔 NOTIFICATION</b>\n\nNotifications have been <b>${status}</b></blockquote>`, { parse_mode: 'HTML' });
        } catch (error) {
            console.error('Toggle notification error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('change_message_format', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            const settings = await loadSettings();
            settings.messageFormat = settings.messageFormat === 'detailed' ? 'simple' : 'detailed';
            await saveSettings(settings);
            const formatName = settings.messageFormat === 'detailed' ? 'DETAILED' : 'SIMPLE';
            
            await ctx.reply(`<blockquote><b>📱 MESSAGE FORMAT</b>\n\nFormat changed to: <b>${formatName}</b></blockquote>`, { parse_mode: 'HTML' });
        } catch (error) {
            console.error('Change format error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('test_connection', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await ctx.reply('<blockquote><b>🔧 TESTING</b>\n\n⏳ Connecting to IVASMS...</blockquote>', { parse_mode: 'HTML' });
            
            const testResult = await testIvasmsConnection();
            
            if (testResult.success && testResult.loginSuccess) {
                await ctx.reply(`<blockquote><b>✅ CONNECTION OK</b>\n\n<b>📡 Status:</b> Connected\n<b>⏱️ Response:</b> ${testResult.responseTime}ms\n<b>🔐 Auth:</b> ${useManualCookie ? 'MANUAL COOKIE' : 'AUTO LOGIN'}</blockquote>`, { parse_mode: 'HTML' });
            } else {
                await ctx.reply(`<blockquote><b>❌ CONNECTION FAIL</b>\n\n<b>Error:</b> ${testResult.error || 'Cookie may be expired'}\n\n<b>Solution:</b>\nClick 🍪 GET COOKIE button to refresh.</blockquote>`, { parse_mode: 'HTML' });
            }
        } catch (error) {
            console.error('Test connection error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('confirm_delete_all', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            const uid = String(ctx.from.id);
            if (!ADMIN_CHAT_IDS.includes(uid)) {
                return await ctx.reply('<blockquote><b>⛔ ACCESS DENIED</b></blockquote>', { parse_mode: 'HTML' });
            }
            
            await saveChatIds([]);
            await fs.writeFile(STATE_FILE, JSON.stringify([], null, 4));
            
            await ctx.reply('<blockquote><b>✅ DATA RESET</b>\n\nAll data has been permanently deleted.</blockquote>', { parse_mode: 'HTML' });
        } catch (error) {
            console.error('Confirm delete all error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('cancel_delete', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            await ctx.reply('<blockquote><b>❌ CANCELLED</b></blockquote>', { parse_mode: 'HTML' });
        } catch (error) {
            console.error('Cancel delete error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.action('back_to_main', async (ctx) => {
        try {
            await ctx.answerCbQuery();
            await ctx.deleteMessage();
            
            const uid = String(ctx.from.id);
            const isAdmin = ADMIN_CHAT_IDS.includes(uid);
            
            const msg = `<blockquote>
<b>🏠 MAIN MENU</b>

<b>👋 Welcome back</b> ${isAdmin ? '👑 Admin' : '👤 User'}

<b>📌 Select an option below:</b>
</blockquote>`;
            
            await ctx.reply(msg, { parse_mode: 'HTML', ...createMainMenu() });
        } catch (error) {
            console.error('Back to main error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.command('batal', async (ctx) => {
        try {
            await saveTempState({ waitingFor: null, tempData: {} });
            await ctx.reply('<blockquote><b>❌ CANCELLED</b></blockquote>', { parse_mode: 'HTML', ...createMainMenu() });
        } catch (error) {
            console.error('Batal command error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b></blockquote>', { parse_mode: 'HTML' });
        }
    });

    bot.on('text', async (ctx) => {
        try {
            const tempState = await loadTempState();
            
            if (tempState.waitingFor === 'add_chat') {
                const newId = ctx.message.text.trim();
                
                if (newId === '/batal') {
                    await saveTempState({ waitingFor: null, tempData: {} });
                    return await ctx.reply('<blockquote><b>❌ CANCELLED</b></blockquote>', { parse_mode: 'HTML', ...createMainMenu() });
                }
                
                const chatIds = await loadChatIds();
                
                if (!chatIds.includes(newId)) {
                    chatIds.push(newId);
                    await saveChatIds(chatIds);
                    await ctx.reply(`<blockquote><b>✅ SUCCESS</b>\n\nChat ID <code>${newId}</code> has been added!</blockquote>`, { parse_mode: 'HTML' });
                } else {
                    await ctx.reply(`<blockquote><b>⚠️ WARNING</b>\n\nChat ID <code>${newId}</code> already exists.</blockquote>`, { parse_mode: 'HTML' });
                }
                
                await saveTempState({ waitingFor: null, tempData: {} });
            } else if (tempState.waitingFor === 'change_interval') {
                const intervalInput = ctx.message.text.trim();
                
                if (intervalInput === '/batal') {
                    await saveTempState({ waitingFor: null, tempData: {} });
                    return await ctx.reply('<blockquote><b>❌ CANCELLED</b></blockquote>', { parse_mode: 'HTML', ...createMainMenu() });
                }
                
                const newInterval = parseInt(intervalInput);
                
                if (isNaN(newInterval) || newInterval < 5 || newInterval > 300) {
                    return await ctx.reply('<blockquote><b>❌ ERROR</b>\n\nInterval must be a number between 5 - 300 seconds.</blockquote>', { parse_mode: 'HTML' });
                }
                
                const settings = await loadSettings();
                settings.interval = newInterval;
                await saveSettings(settings);
                POLLING_INTERVAL_SECONDS = newInterval;
                
                await ctx.reply(`<blockquote><b>✅ SUCCESS</b>\n\nPolling interval changed to <b>${newInterval} seconds</b>.</blockquote>`, { parse_mode: 'HTML' });
                await saveTempState({ waitingFor: null, tempData: {} });
            }
        } catch (error) {
            console.error('Text handler error:', error);
            await ctx.reply('<blockquote><b>❌ ERROR</b>\nAn error occurred.</blockquote>', { parse_mode: 'HTML' });
        }
    });
}

async function main() {
    if (YOUR_BOT_TOKEN === "YOUR_TOKEN_HERE") {
        console.error("ERROR: Please change YOUR_BOT_TOKEN!");
        process.exit(1);
    }
    
    const bot = new Telegraf(YOUR_BOT_TOKEN);
    const settings = await loadSettings();
    POLLING_INTERVAL_SECONDS = settings.interval;
    
    await initAxiosWithCookie();
    
    const cookieExists = await loadCookies();
    if (cookieExists && cookieExists.cookie) {
        console.log('✅ Manual cookie found! Bot will use this cookie.');
        useManualCookie = true;
    } else {
        console.log('⚠️ No manual cookie found. Click 🍪 GET COOKIE button to get cookie.');
    }
    
    setupCommands(bot);
    
    await bot.launch();
    console.log(`\n✅ Bot started!`);
    console.log(`📡 Interval: ${POLLING_INTERVAL_SECONDS} seconds`);
    console.log(`👥 Admin IDs: ${ADMIN_CHAT_IDS.join(', ')}`);
    console.log(`🔐 Auth mode: ${useManualCookie ? 'MANUAL COOKIE' : 'AWAITING COOKIE'}`);
    console.log(`\n💡 Click 🍪 GET COOKIE button in bot menu to authenticate.\n`);
    
    setInterval(() => checkSms(bot), POLLING_INTERVAL_SECONDS * 1000);
    setTimeout(() => checkSms(bot), 5000);
    
    process.once('SIGINT', () => { console.log('Bot stopped'); bot.stop('SIGINT'); process.exit(0); });
    process.once('SIGTERM', () => { console.log('Bot stopped'); bot.stop('SIGTERM'); process.exit(0); });
}

if (require.main === module) {
    main().catch(error => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
}

module.exports = { main };